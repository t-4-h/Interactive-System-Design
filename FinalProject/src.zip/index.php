<!DOCTYPE html>
<html lang="en">
<head>
<title>Main Page</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script>
function showHint(str)
{
    if (str.length==0)
    { 
        document.getElementById("txtHint").innerHTML="";
        return;
    }
    if (window.XMLHttpRequest)
    {
        // IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp=new XMLHttpRequest();
    }
    else
    {    
        //IE6, IE5 
        xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
    }
    xmlhttp.onreadystatechange=function()
    {
        if (xmlhttp.readyState==4 && xmlhttp.status==200)
        {
            document.getElementById("txtHint").innerHTML=xmlhttp.responseText;
        }
    }
    xmlhttp.open("GET","gethint.php?q="+str,true);
    xmlhttp.send();
}
</script>
<style css>
      ul.nav-pills {
      top: 20px;
      position: fixed;
      width:200px;
  }
    no {
    padding-top: 100px;
  }
    adBtn{
        align-content: center;
        padding-left: 50px;
    }
    body{
        position:relative;
         padding-top: 100px;
        background-color: cornsilk;
    }
  .app_page1 {
  margin: 0;
      padding-top: 100px;
  overflow: hidden;
  height:100%;
}
    .medium{
        position: fixed;
        top: 100px;
        left:50%;
		width:50%;
		background-color:#FFA07A;
    }
@media (min-width: 768px){
  right {
    position: absolute;
    top: 0;
    bottom: 0;
    right: 0;
    overflow-y: scroll;
    width: 50%;
  }
}
#left {
  background-color: #FC6E51;
  text-align: center;
  height:100%;
}
#middle{
  background-color: lightgreen;
  text-align: center;
  height:100%;
}
#right {
  height:700px;
  text-align: center;
  overflow-y: scroll;
}
h4{
  padding: 10px 0; 
}
.tool-card{
  border: 2px solid black;
  padding: 10px 10px;
  margin: 10px 0;
}
@media screen and (max-width: 810px) {
    #section1, #section2, #section3, #section41, #section42  {
        margin-left: 150px;
    }
  }
  #navBarSearchForm input[type=text]{width:500px !important;}
</style>
</head>
<body data-spy="scroll" data-target="#myScrollspy" data-offset="20">
<?php
    $servername = "localhost";
    $username = "root";
    $password = "mysql";
    $dbname = "isd";
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->
connect_error) {
        die($conn->connect_error);
    }
    $id=$_GET["id"];
    $sql = "SELECT * FROM `main` WHERE surgeryid=$id order by mainid";
    $result = $conn->query($sql);
	?>
<!-- Navigation Bar-->
<div class="navbar navbar-inverse navbar-fixed-top" role="navigation">
	<div class="navbar-header">
		<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
		<span class="sr-only">Toggle navigation</span>
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
		</button>
		<a class="navbar-brand" rel="home" href="AllProcedures.html" title="All Procedures Homepage"><img style="max-width:100px;max-height: 40px; margin-top: -7px;" src="surgeonLogo.png"></a>
	</div>
	<ul class="nav navbar-nav navbar-right">
		<li><a href="login.html"><span class="glyphicon glyphicon-log-out"></span>Logout</a></li>
	</ul>
	<div class="collapse navbar-collapse navbar-ex1-collapse">
		<div class="col-sm-4 col-md-8 pull-right">
			<form class="navbar-form" role="search" id="navBarSearchForm">
				<div class="input-group">
					<input type="text" class="form-control" placeholder="Search Other Surgery" name="srch-term" id="srch-term">
					<div class="input-group-btn">
						<button class="btn btn-default" type="submit"><i class="glyphicon glyphicon-search"></i></button>
					</div>
				</div>
			</form>
		</div>
	</div>
</div>
<!--Navigation Bar ends -->
<div class="container">
	<!-- 3 Column Body -->
	<div class="row">
		<div class="col-lg-6">
			<div class="container-fluid">
            <div class="modal fade" id="myModal" role="dialog">
    
   					<div class="modal-dialog">

              <!-- Modal content
                Add micro step textarea displays with this
                Edit the functionality here
-->
              <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                  <h4 class="modal-title">Add Micro Step</h4>
                </div>
                <div class="modal-body">
                  <div class="form-group">
                      <label for="comment">Add your Micro Step here:</label>
                      <textarea class="form-control" rows="5"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-success"  type="submit" >Submit for Review</button>
                  <button type="button" class="btn btn-default btn-danger" data-dismiss="modal">Close</button>
                </div>
              </div>

			</div>
			
		</div>

		<div class="modal fade" id="tipModal" role="dialog">
            <div class="modal-dialog">


              <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                  <h4 class="modal-title">Add Tips</h4>
                </div>
                <div class="modal-body">
                  <div class="form-group">
                      <label for="comment">Add your Teaching Tip here:</label>
                      <textarea class="form-control" rows="5"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-success"  type="submit" >Submit for Review</button>
                  <button type="button" class="btn btn-default btn-danger" data-dismiss="modal">Close</button>
                </div>
              </div>

            </div>
          </div>
				<div class="row">
					<nav class="col-md-6" id="myScrollspy">
					<ul class="nav nav-pills nav-stacked" data-spy="affix" data-offset-top="205" data-off>
						<li><a>
						<h1>Main Steps</h1>
						</a></li>
						<?php
							while($row = $result->
						fetch_assoc()){
								echo "
						<li><a href='#section$row[mainid]'>$row[mainstep]</a></li>
						\n";
							}
						?>
					</ul>
					</nav>
					<div class="col-md-6">
						<h1>Micro Steps</h1>
						<?php
								$sql = "SELECT * FROM `main` WHERE surgeryid=$id order by mainid";
								$result = $conn->query($sql);
								$count = 0;
								while($row = $result->fetch_assoc()){
									echo "
										<div class='list-group' id='section$row[mainid]'>
									";
									$count++;
									echo"<h2>Step $count</h2>";
									echo "<a id='addBtn'><span class='glyphicon glyphicon-plus' data-toggle='modal' data-target='#myModal'></a>";
					
										$sql = "SELECT * FROM `micro` WHERE mainid=$row[mainid] order by microid";
										$result1 = $conn->query($sql);
										while($row1 = $result1->fetch_assoc()){
											echo " <button class='list-group-item' onclick='showHint($row1[microid])'>\n";
											echo " $row1[microstep]</br>\n";
											
											echo "<a id='addBtn'><span class='glyphicon glyphicon-plus' data-toggle='modal' data-target='#myModal'></a>";
											echo "</button>\n";
										}
									echo "</div>";
								}
							?>
					</div>
				</div>
			</div>
			<div class="col-lg-6">
				<div class="col-lg-12 medium" id="right">
					<h1>Tips</h1>
					<span id="txtHint"></span>
					<a href="#" id="addBtn"><span class="glyphicon glyphicon-plus" data-toggle="modal" data-target="#tipModal"></a>

			</div>

		</div>
	</div>
</div>
</div>
</body>
</html>