<?php

    $servername = "localhost";
    $username = "root";
    $password = "mysql";
    $dbname = "isd";
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die($conn->connect_error);
    }
    $id=$_GET["q"];
    $sql = "SELECT * FROM `hint` WHERE microid=$id order by hintid";
    $result = $conn->query($sql);
    $count = 0;
    if(mysqli_num_rows($result)==0){
        echo "<h2>No Tip for This Microstep.</h2>";
    }
    while ($row = $result->fetch_assoc()) {
        $count++;
        echo "<div>\n";
        echo "   <h1>Tip $count</h1>\n";
        echo "   <p>$row[hint]</p>\n";
        echo "</div>\n";
    }

?>