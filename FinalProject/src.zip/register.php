<?php

    $servername = "localhost";
    $username = "root";
    $password = "mysql";
    $dbname = "isd";


    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die($conn->connect_error);
    }

   
$username = $_POST['username'];
$email = $_POST['email'];
$password = $_POST['password'];    
if (!empty($username)){
  if (!empty($password)){
      $sql = "INSERT INTO user (username, email, password) values ('$username','$email', '$password')";
      if ($conn->query($sql)){
        echo "<script> alert('New User Created');
          window.location.href='login.html';
          </script>";   
      }
      else{
        echo "Error: ";
        }
      $conn->close();
  }
  else{
    echo "<script> alert('Empty password');
          window.location.href='login.html';
          </script>";   
    die();
  }
}
else{
  echo "<script> alert('Empty Username');
          window.location.href='login.html';
          </script>";   
  die();
}
?>

